# Photo Arena (Android, Kotlin)

Take a photo, and the app finds everyday objects in it. A toothbrush becomes a
weapon, a sink becomes a platform, a chair a hurdle and a cup something to throw.
Then two stick figures fight in a 2D arena built from your photo.

## Build the APK

1. Install Android Studio (Koala or newer).
2. File → Open → select this `PhotoArena` folder. Let Gradle sync finish.
3. Build → Build App Bundle(s) / APK(s) → Build APK(s).
   The first build also downloads the detection model (~4 MB) into
   `app/src/main/assets/`.
4. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.
   Copy it to your phone and open it (allow "install unknown apps"),
   or plug the phone in with USB debugging on and press Run ▶.

If the model download is blocked (e.g. a company proxy), download it manually and put it at
`app/src/main/assets/efficientdet_lite0.tflite`:
https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/1/efficientdet_lite0.tflite

## How it works

| File | What it does |
| --- | --- |
| `MainActivity.kt` | Take photo / pick from gallery, run the scan, show results |
| `Detector.kt` | On-device object detection (MediaPipe, COCO's 80 objects), cuts each object out of the photo |
| `Roles.kt` | Which object becomes what (weapon, throwable, hurdle, platform) and weapon stats |
| `ScanView.kt` | Photo with scan line and coloured boxes |
| `GameView.kt` | The arena: physics, pickups, fighters, rival AI, touch controls |

Change `Roles.kt` to tune the game: e.g. make the toothbrush stronger or turn
a sink into a hurdle.

## Controls

◀ ▶ move, Jump, Hit (becomes Throw while holding a throwable).
Walk over a weapon or throwable to pick it up. Back returns to the photo screen.
