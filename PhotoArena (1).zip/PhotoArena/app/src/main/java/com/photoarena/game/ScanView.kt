package com.photoarena.game

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.min

/** Shows the photo with a scan line while detecting, then boxes around found objects. */
class ScanView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var photo: Bitmap? = null
        set(value) { field = value; invalidate() }
    var items: List<DetectedItem> = emptyList()
        set(value) { field = value; invalidate() }
    var scanning = false
        set(value) { field = value; invalidate() }

    private val dp = resources.displayMetrics.density
    private val dst = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * dp }
    private val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tagText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0E1116"); textSize = 12f * dp; isFakeBoldText = true }
    private val hintText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#9AA4B2"); textSize = 15f * dp; textAlign = Paint.Align.CENTER }
    private val scanPaint = Paint().apply { color = Color.parseColor("#C6F432"); strokeWidth = 3f * dp }
    private val bgPaint = Paint().apply { color = Color.parseColor("#161B22") }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 16 * dp, 16 * dp, bgPaint)
        val p = photo
        if (p == null) {
            canvas.drawText("Take a photo of a room, a sink, a desk…", width / 2f, height / 2f, hintText)
            return
        }

        val s = min(width.toFloat() / p.width, height.toFloat() / p.height)
        val w = p.width * s
        val h = p.height * s
        dst.set((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2)
        canvas.drawBitmap(p, null, dst, bmpPaint)

        for (item in items) {
            val r = RectF(
                dst.left + item.box.left * s, dst.top + item.box.top * s,
                dst.left + item.box.right * s, dst.top + item.box.bottom * s
            )
            boxPaint.color = item.role.color
            canvas.drawRoundRect(r, 6 * dp, 6 * dp, boxPaint)

            val tag = "${item.label} · ${item.role.label.lowercase()}"
            val tw = tagText.measureText(tag) + 10 * dp
            val th = 18 * dp
            val ty = if (r.top - th < dst.top) r.top else r.top - th
            tagPaint.color = item.role.color
            canvas.drawRoundRect(r.left, ty, r.left + tw, ty + th, 4 * dp, 4 * dp, tagPaint)
            canvas.drawText(tag, r.left + 5 * dp, ty + th - 5 * dp, tagText)
        }

        if (scanning) {
            val t = (SystemClock.uptimeMillis() % 1600) / 800f   // 0..2
            val phase = 1f - abs(1f - t)                           // 0..1..0
            val y = dst.top + phase * dst.height()
            canvas.drawLine(dst.left, y, dst.right, y, scanPaint)
            postInvalidateOnAnimation()
        }
    }
}
