package com.photoarena.game

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF

/** What a detected object turns into inside the arena. */
enum class Role(val label: String, val color: Int) {
    WEAPON("Weapon", Color.parseColor("#FF9F4A")),
    THROWABLE("Throwable", Color.parseColor("#FFD24A")),
    HURDLE("Hurdle", Color.parseColor("#C6F432")),
    PLATFORM("Platform", Color.parseColor("#7CC4FF"))
}

/** damage per hit, reach as a fraction of screen height, seconds between swings */
data class WeaponStats(val damage: Int, val reach: Float, val cooldown: Float)

/** One object found in the photo, with its picture cut out of the photo. */
class DetectedItem(
    val label: String,
    val role: Role,
    val score: Float,
    val box: RectF,      // position in the photo, in photo pixels
    val sprite: Bitmap   // the object cut out of the photo
)

/** Shares the scan result between the scan screen and the game screen. */
object GameSession {
    var photo: Bitmap? = null
    var items: List<DetectedItem> = emptyList()
}

/**
 * Maps detector labels (the 80 COCO object names) to game roles.
 * Add or move names here to change how the game treats objects.
 */
object Roles {
    private val weapons = mapOf(
        "toothbrush" to WeaponStats(damage = 8, reach = 0.11f, cooldown = 0.22f),   // fast, weak
        "fork" to WeaponStats(10, 0.10f, 0.28f),
        "spoon" to WeaponStats(8, 0.10f, 0.25f),
        "knife" to WeaponStats(14, 0.11f, 0.32f),
        "scissors" to WeaponStats(13, 0.10f, 0.30f),
        "hair drier" to WeaponStats(12, 0.12f, 0.35f),
        "umbrella" to WeaponStats(16, 0.20f, 0.45f),
        "tennis racket" to WeaponStats(17, 0.18f, 0.45f),
        "baseball bat" to WeaponStats(22, 0.20f, 0.55f),                            // slow, strong
        "skis" to WeaponStats(18, 0.24f, 0.60f)
    )
    private val throwables = setOf(
        "bottle", "cup", "wine glass", "bowl", "banana", "apple", "orange", "book",
        "sports ball", "teddy bear", "mouse", "remote", "cell phone", "vase", "clock",
        "donut", "sandwich", "frisbee", "carrot", "broccoli", "pizza", "cake", "hot dog"
    )
    private val platforms = setOf(
        "sink", "dining table", "bed", "toilet", "couch", "refrigerator", "oven",
        "microwave", "tv", "bench", "car", "truck", "bus", "boat", "toaster"
    )
    private val hurdles = setOf(
        "chair", "suitcase", "backpack", "handbag", "potted plant", "fire hydrant",
        "laptop", "keyboard", "stop sign", "parking meter", "bicycle", "motorcycle"
    )
    private val ignored = setOf("person")

    fun roleFor(label: String): Role? {
        val l = label.lowercase()
        return when {
            l in ignored -> null
            l in weapons -> Role.WEAPON
            l in throwables -> Role.THROWABLE
            l in platforms -> Role.PLATFORM
            l in hurdles -> Role.HURDLE
            else -> Role.HURDLE // animals and anything else: something to jump over
        }
    }

    fun weaponStats(label: String): WeaponStats =
        weapons[label.lowercase()] ?: WeaponStats(12, 0.13f, 0.35f)

    val FISTS = WeaponStats(damage = 6, reach = 0.07f, cooldown = 0.30f)
}
