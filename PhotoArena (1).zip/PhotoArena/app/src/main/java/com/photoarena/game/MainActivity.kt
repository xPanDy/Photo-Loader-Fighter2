package com.photoarena.game

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var scanView: ScanView
    private lateinit var status: TextView
    private lateinit var found: TextView
    private lateinit var arenaBtn: Button

    private var photoUri: Uri? = null
    private val worker = Executors.newSingleThreadExecutor()
    private var detector: Detector? = null   // only touched on the worker thread

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) photoUri?.let { scan(it) }
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let { scan(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scanView = findViewById(R.id.scanView)
        status = findViewById(R.id.status)
        found = findViewById(R.id.found)
        arenaBtn = findViewById(R.id.arenaBtn)

        findViewById<Button>(R.id.takeBtn).setOnClickListener {
            val dir = File(cacheDir, "photos").apply { mkdirs() }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", File(dir, "capture.jpg"))
            photoUri = uri
            takePicture.launch(uri)
        }
        findViewById<Button>(R.id.galleryBtn).setOnClickListener { pickImage.launch("image/*") }
        arenaBtn.setOnClickListener { startActivity(Intent(this, GameActivity::class.java)) }
    }

    private fun scan(uri: Uri) {
        arenaBtn.isEnabled = false
        scanView.items = emptyList()
        scanView.scanning = true
        status.text = "Scanning…"
        found.text = ""

        worker.execute {
            try {
                val photo = ImageLoader.load(this, uri, maxDim = 1280)
                runOnUiThread { scanView.photo = photo }

                val det = detector ?: Detector(this).also { detector = it }
                val items = det.detect(photo)

                runOnUiThread {
                    scanView.scanning = false
                    scanView.items = items
                    GameSession.photo = photo
                    GameSession.items = items
                    status.text = if (items.isEmpty())
                        "No objects found. You can still fight, or try another photo."
                    else "Found ${items.size} object(s):"
                    found.text = items.joinToString("\n") { "${it.label} → ${it.role.label}" }
                    arenaBtn.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    scanView.scanning = false
                    status.text = "Couldn't scan this photo: ${e.message}"
                }
            }
        }
    }

    override fun onDestroy() {
        worker.execute { detector?.close(); detector = null }
        worker.shutdown()
        super.onDestroy()
    }
}
