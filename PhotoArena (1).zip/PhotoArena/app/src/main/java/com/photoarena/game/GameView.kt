package com.photoarena.game

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * The arena: the photo becomes the background, detected objects become
 * platforms, hurdles and pickups, and two stick figures fight.
 *
 * All sizes are based on the screen height (H) so it plays the same on any phone.
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class GameView(
    context: Context,
    private val photo: Bitmap,
    private val detected: List<DetectedItem>
) : View(context), Choreographer.FrameCallback {

    // ---------- world objects ----------

    private class Solid(val item: DetectedItem?, val rect: RectF)

    private class Pickup(val item: DetectedItem, val rect: RectF) {
        var taken = false
    }

    private class Projectile(
        val item: DetectedItem, var x: Float, var y: Float,
        var vx: Float, var vy: Float, val owner: Fighter, val size: Float
    ) {
        var alive = true
        var spin = 0f
    }

    private class Fighter(val name: String, val color: Int) {
        var x = 0f; var y = 0f          // y = feet
        var vx = 0f; var vy = 0f
        var w = 0f; var h = 0f
        var onGround = false
        var facing = 1
        var hp = 100
        var weapon: DetectedItem? = null
        var throwable: DetectedItem? = null
        var attackTime = 0f
        var cooldown = 0f
        var hurtTime = 0f
        var blocked = false
    }

    // ---------- state ----------

    private var W = 0f
    private var H = 0f
    private var floorY = 0f
    private var gravity = 0f
    private var jumpV = 0f
    private var playerSpeed = 0f
    private var enemySpeed = 0f

    private val solids = mutableListOf<Solid>()
    private val pickups = mutableListOf<Pickup>()
    private val projectiles = mutableListOf<Projectile>()
    private val player = Fighter("You", Color.parseColor("#C6F432"))
    private val enemy = Fighter("Rival", Color.parseColor("#7CC4FF"))

    private var worldReady = false
    private var running = false
    private var lastNanos = 0L
    private var time = 0f

    private var message = ""
    private var messageTime = 0f
    private var gameOver = false
    private var overTime = 0f

    // controls
    private var holdLeft = false
    private var holdRight = false
    private var jumpQueued = false
    private var attackQueued = false
    private val btnLeft = PointF()
    private val btnRight = PointF()
    private val btnJump = PointF()
    private val btnAttack = PointF()
    private var btnR = 0f

    // ---------- paints ----------

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val limb = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val photoSrc = Rect()
    private val tmpRect = RectF()
    private val arrow = Path()

    // ---------- setup ----------

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w == 0 || h == 0) return
        W = w.toFloat(); H = h.toFloat()
        floorY = H * 0.80f
        gravity = H * 3.2f
        jumpV = sqrt(2f * gravity * H * 0.32f)   // jumps about 0.32 H high
        playerSpeed = H * 0.75f
        enemySpeed = H * 0.55f
        btnR = H * 0.085f
        btnLeft.set(btnR * 1.5f, H - btnR * 1.25f)
        btnRight.set(btnR * 4.0f, H - btnR * 1.25f)
        btnAttack.set(W - btnR * 1.5f, H - btnR * 1.25f)
        btnJump.set(W - btnR * 4.0f, H - btnR * 1.25f)

        // background: crop the photo to fill the screen
        val sa = W / H
        val pa = photo.width.toFloat() / photo.height
        if (pa > sa) {
            val cw = (photo.height * sa).toInt()
            val l = (photo.width - cw) / 2
            photoSrc.set(l, 0, l + cw, photo.height)
        } else {
            val ch = (photo.width / sa).toInt()
            val t = (photo.height - ch) / 2
            photoSrc.set(0, t, photo.width, t + ch)
        }
        buildWorld()
    }

    private fun buildWorld() {
        solids.clear(); pickups.clear(); projectiles.clear()
        val left = W * 0.16f
        val right = W * 0.84f
        val span = right - left
        val gap = H * 0.10f

        // Platforms and hurdles, kept in the same left-to-right order as in the photo
        val solidItems = detected
            .filter { it.role == Role.PLATFORM || it.role == Role.HURDLE }
            .sortedByDescending { it.score }.take(5)
            .sortedBy { it.box.centerX() }
        var cursor = left
        for (item in solidItems) {
            val isPlatform = item.role == Role.PLATFORM
            val targetH = if (isPlatform) H * 0.22f else H * 0.13f
            val aspect = item.sprite.width.toFloat() / item.sprite.height
            val w = (targetH * aspect).coerceIn(H * 0.06f, if (isPlatform) W * 0.22f else W * 0.09f)
            var x = max(left + (item.box.centerX() / photo.width) * span - w / 2, cursor)
            if (x + w > right) x = right - w
            if (x < cursor) continue // no room left
            solids += Solid(item, RectF(x, floorY - targetH, x + w, floorY))
            cursor = x + w + gap
        }

        // Weapons and throwables lie around as pickups
        val pickupItems = detected
            .filter { it.role == Role.WEAPON || it.role == Role.THROWABLE }
            .sortedByDescending { it.score }.take(5)
        for ((i, item) in pickupItems.withIndex()) {
            val targetH = if (item.role == Role.WEAPON) H * 0.11f else H * 0.07f
            val aspect = item.sprite.width.toFloat() / item.sprite.height
            val w = (targetH * aspect).coerceIn(H * 0.03f, H * 0.14f)
            var cx = left + (item.box.centerX() / photo.width) * span
            cx += (i % 2) * H * 0.04f
            cx = cx.coerceIn(W * 0.15f, W * 0.85f)
            val under = solids.firstOrNull { cx > it.rect.left && cx < it.rect.right }
            val bottom = under?.rect?.top ?: floorY
            pickups += Pickup(item, RectF(cx - w / 2, bottom - targetH, cx + w / 2, bottom))
        }

        // Nothing usable in the photo: add two plain blocks so the fight still works
        if (solids.isEmpty() && pickups.isEmpty()) {
            solids += Solid(null, RectF(W * 0.32f, floorY - H * 0.13f, W * 0.32f + H * 0.12f, floorY))
            solids += Solid(null, RectF(W * 0.55f, floorY - H * 0.22f, W * 0.55f + W * 0.15f, floorY))
        }

        resetFighter(player, W * 0.06f, 1)
        resetFighter(enemy, W * 0.94f, -1)
        gameOver = false
        overTime = 0f
        val firstWeapon = pickups.firstOrNull { it.item.role == Role.WEAPON }
        showMessage(if (firstWeapon != null) "Fight! Grab the ${firstWeapon.item.label}!" else "Fight!")
        worldReady = true
    }

    private fun resetFighter(f: Fighter, x: Float, facing: Int) {
        f.w = H * 0.06f; f.h = H * 0.17f
        f.x = x; f.y = floorY; f.vx = 0f; f.vy = 0f
        f.facing = facing; f.hp = 100
        f.weapon = null; f.throwable = null
        f.attackTime = 0f; f.cooldown = 0f; f.hurtTime = 0f
    }

    private fun showMessage(m: String) { message = m; messageTime = 2.2f }

    // ---------- game loop ----------

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        lastNanos = 0L
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDetachedFromWindow() {
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
        super.onDetachedFromWindow()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (lastNanos != 0L && worldReady) {
            val dt = ((frameTimeNanos - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.033f)
            update(dt)
        }
        lastNanos = frameTimeNanos
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun update(dt: Float) {
        time += dt
        messageTime -= dt
        if (gameOver) { overTime += dt; return }

        // player input
        val move = (if (holdRight) 1 else 0) - (if (holdLeft) 1 else 0)
        if (move != 0) player.facing = move
        if (player.hurtTime <= 0f) player.vx = move * playerSpeed
        if (jumpQueued && player.onGround) player.vy = -jumpV
        if (attackQueued) attack(player)
        jumpQueued = false
        attackQueued = false

        think(enemy, dt)

        for (f in listOf(player, enemy)) {
            if (f.hurtTime > 0f) f.vx *= 0.9f
            moveFighter(f, dt)
            collectPickups(f)
            f.attackTime -= dt; f.cooldown -= dt; f.hurtTime -= dt
        }
        updateProjectiles(dt)

        if (player.hp <= 0 || enemy.hp <= 0) {
            gameOver = true
            overTime = 0f
        }
    }

    // ---------- physics ----------

    private fun moveFighter(f: Fighter, dt: Float) {
        f.vy += gravity * dt
        val prevFeet = f.y

        // horizontal: objects block you unless you're standing on top of them
        f.x += f.vx * dt
        f.blocked = false
        for (s in solids) {
            val r = s.rect
            val overlapX = f.x + f.w / 2 > r.left && f.x - f.w / 2 < r.right
            if (overlapX && f.y > r.top + 1f) {
                f.x = if (f.x < r.centerX()) r.left - f.w / 2 else r.right + f.w / 2
                f.blocked = true
            }
        }
        f.x = f.x.coerceIn(f.w / 2, W - f.w / 2)

        // vertical: land on tops of objects or the floor
        f.y += f.vy * dt
        f.onGround = false
        if (f.vy >= 0f) {
            for (s in solids) {
                val r = s.rect
                val feetOver = f.x + f.w * 0.3f > r.left && f.x - f.w * 0.3f < r.right
                if (feetOver && prevFeet <= r.top + 1f && f.y >= r.top) {
                    f.y = r.top; f.vy = 0f; f.onGround = true
                }
            }
        }
        if (f.y >= floorY) { f.y = floorY; f.vy = 0f; f.onGround = true }
    }

    private fun collectPickups(f: Fighter) {
        for (p in pickups) {
            if (p.taken) continue
            val touching = f.x + f.w / 2 > p.rect.left && f.x - f.w / 2 < p.rect.right &&
                f.y > p.rect.top && f.y - f.h < p.rect.bottom
            if (!touching) continue
            if (p.item.role == Role.WEAPON && f.weapon == null) {
                f.weapon = p.item; p.taken = true
                showMessage(if (f === player) "You picked up the ${p.item.label}!" else "Rival grabbed the ${p.item.label}!")
            } else if (p.item.role == Role.THROWABLE && f.throwable == null) {
                f.throwable = p.item; p.taken = true
                if (f === player) showMessage("Got a ${p.item.label}. Tap Throw!")
            }
        }
    }

    // ---------- combat ----------

    private fun other(f: Fighter) = if (f === player) enemy else player

    private fun attack(f: Fighter) {
        if (f.cooldown > 0f || f.hp <= 0) return
        val t = f.throwable
        if (t != null) {
            projectiles += Projectile(
                t, f.x + f.facing * f.w, f.y - f.h * 0.75f,
                f.facing * H * 1.7f, -H * 0.55f, f, H * 0.07f
            )
            f.throwable = null
            f.cooldown = 0.45f
            f.attackTime = 0.2f
            return
        }
        val stats = f.weapon?.let { Roles.weaponStats(it.label) } ?: Roles.FISTS
        f.attackTime = 0.2f
        f.cooldown = stats.cooldown
        val target = other(f)
        val reach = stats.reach * H + f.w / 2 + target.w / 2
        val dx = (target.x - f.x) * f.facing
        val sameHeight = abs((target.y - target.h / 2) - (f.y - f.h / 2)) < f.h * 0.8f
        if (dx > -f.w * 0.3f && dx < reach && sameHeight) hit(target, stats.damage, f.facing)
    }

    private fun hit(target: Fighter, damage: Int, dir: Int) {
        target.hp = max(0, target.hp - damage)
        target.vx = dir * H * 0.9f
        target.vy = -H * 0.5f
        target.hurtTime = 0.25f
    }

    private fun updateProjectiles(dt: Float) {
        for (p in projectiles) {
            if (!p.alive) continue
            p.vy += gravity * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.spin += dt * 720f
            val target = other(p.owner)
            if (abs(p.x - target.x) < target.w / 2 + p.size / 2 && p.y > target.y - target.h && p.y < target.y) {
                hit(target, 14, if (p.vx > 0) 1 else -1)
                p.alive = false
            }
            if (p.y >= floorY || p.x < 0 || p.x > W || solids.any { it.rect.contains(p.x, p.y) }) p.alive = false
        }
        projectiles.removeAll { !it.alive }
    }

    // ---------- rival AI ----------

    private fun think(e: Fighter, dt: Float) {
        if (e.hp <= 0) { e.vx = 0f; return }
        val dx = player.x - e.x
        val dir = if (dx >= 0) 1 else -1
        e.facing = dir
        val stats = e.weapon?.let { Roles.weaponStats(it.label) } ?: Roles.FISTS
        val reach = stats.reach * H + e.w

        // throw from a distance
        if (e.throwable != null && abs(dx) in (W * 0.15f)..(W * 0.6f) && e.cooldown <= 0f && Random.nextFloat() < dt * 1.5f) {
            attack(e)
        }

        val desire = when {
            abs(dx) > reach * 0.8f -> dir.toFloat()
            abs(dx) < reach * 0.3f -> -dir * 0.5f
            else -> 0f
        }
        if (e.hurtTime <= 0f) e.vx = desire * enemySpeed

        if (e.onGround && e.blocked) e.vy = -jumpV                      // hop over hurdles
        if (e.onGround && player.y < e.y - H * 0.1f && abs(dx) < W * 0.18f && Random.nextFloat() < dt * 2f) {
            e.vy = -jumpV                                               // follow you onto platforms
        }
        if (abs(dx) <= reach && e.cooldown <= 0f && Random.nextFloat() < dt * 3f) attack(e)
    }

    // ---------- drawing ----------

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!worldReady) return

        tmpRect.set(0f, 0f, W, H)
        canvas.drawBitmap(photo, photoSrc, tmpRect, bmpPaint)
        canvas.drawColor(Color.argb(175, 14, 17, 22))

        fill.color = Color.parseColor("#161B22")
        canvas.drawRect(0f, floorY, W, H, fill)
        fill.color = Color.parseColor("#5A5046")
        canvas.drawRect(0f, floorY, W, floorY + H * 0.008f, fill)

        text.textSize = H * 0.032f
        text.textAlign = Paint.Align.CENTER
        stroke.strokeWidth = H * 0.006f
        for (s in solids) {
            val item = s.item
            if (item != null) {
                canvas.drawBitmap(item.sprite, null, s.rect, bmpPaint)
                stroke.color = item.role.color
                text.color = item.role.color
                canvas.drawText(item.label, s.rect.centerX(), s.rect.top - H * 0.015f, text)
            } else {
                fill.color = Color.parseColor("#3A424E")
                canvas.drawRect(s.rect, fill)
                stroke.color = Color.parseColor("#C6F432")
            }
            canvas.drawRect(s.rect, stroke)
        }

        for (p in pickups) {
            if (p.taken) continue
            val bob = sin(time * 3f) * H * 0.01f
            tmpRect.set(p.rect.left, p.rect.top + bob, p.rect.right, p.rect.bottom + bob)
            canvas.drawBitmap(p.item.sprite, null, tmpRect, bmpPaint)
            stroke.color = p.item.role.color
            canvas.drawRoundRect(tmpRect, H * 0.01f, H * 0.01f, stroke)
        }

        for (p in projectiles) {
            canvas.save()
            canvas.translate(p.x, p.y)
            canvas.rotate(p.spin)
            drawSpriteFit(canvas, p.item.sprite, p.size)
            canvas.restore()
        }

        drawFighter(canvas, enemy)
        drawFighter(canvas, player)
        drawHud(canvas)
        drawControls(canvas)

        if (messageTime > 0f && !gameOver) {
            text.textAlign = Paint.Align.CENTER
            text.textSize = H * 0.05f
            text.color = Color.WHITE
            text.alpha = (min(1f, messageTime) * 255).toInt()
            canvas.drawText(message, W / 2, H * 0.22f, text)
            text.alpha = 255
        }

        if (gameOver) {
            canvas.drawColor(Color.argb(190, 14, 17, 22))
            text.textAlign = Paint.Align.CENTER
            text.textSize = H * 0.16f
            text.color = if (enemy.hp <= 0) Color.parseColor("#C6F432") else Color.parseColor("#FF9F4A")
            canvas.drawText(if (enemy.hp <= 0) "You win!" else "K.O.", W / 2, H * 0.48f, text)
            text.textSize = H * 0.05f
            text.color = Color.WHITE
            canvas.drawText("Tap to fight again · Back for a new photo", W / 2, H * 0.62f, text)
        }
    }

    /** Draws a sprite centred on (0,0) with its longest side = size. */
    private fun drawSpriteFit(canvas: Canvas, bmp: Bitmap, size: Float) {
        val s = size / max(bmp.width, bmp.height)
        val w = bmp.width * s
        val h = bmp.height * s
        tmpRect.set(-w / 2, -h / 2, w / 2, h / 2)
        canvas.drawBitmap(bmp, null, tmpRect, bmpPaint)
    }

    private fun drawFighter(canvas: Canvas, f: Fighter) {
        limb.color = if (f.hurtTime > 0f) Color.WHITE else f.color
        limb.strokeWidth = H * 0.012f
        if (f.hp <= 0) limb.alpha = 90

        val headR = f.h * 0.11f
        val top = f.y - f.h
        val neckY = top + headR * 2
        val hipY = f.y - f.h * 0.42f
        val shoulderY = neckY + f.h * 0.06f

        canvas.drawCircle(f.x, top + headR, headR, limb)
        canvas.drawLine(f.x, neckY, f.x, hipY, limb)

        val walking = f.onGround && abs(f.vx) > 1f
        val stride = if (walking) sin(time * 14f) * f.w * 0.55f else f.w * 0.35f
        canvas.drawLine(f.x, hipY, f.x + stride, f.y, limb)
        canvas.drawLine(f.x, hipY, f.x - stride, f.y, limb)

        // back arm
        canvas.drawLine(f.x, shoulderY, f.x - f.facing * f.w * 0.4f, shoulderY + f.h * 0.18f, limb)

        // front arm, extended while attacking
        val attacking = f.attackTime > 0f
        val handX = if (attacking) f.x + f.facing * f.w * 0.95f else f.x + f.facing * f.w * 0.45f
        val handY = if (attacking) shoulderY else shoulderY + f.h * 0.16f
        canvas.drawLine(f.x, shoulderY, handX, handY, limb)
        limb.alpha = 255

        val weapon = f.weapon
        if (weapon != null) {
            val bmp = weapon.sprite
            val length = H * 0.12f
            val s = length / max(bmp.width, bmp.height)
            val bw = bmp.width * s
            val bh = bmp.height * s
            canvas.save()
            canvas.translate(handX, handY)
            canvas.rotate(f.facing * if (attacking) 90f else 25f)
            if (bw > bh) {
                // landscape sprite: turn it so its long side points "up" out of the hand
                canvas.rotate(-90f)
                tmpRect.set(0f, -bh / 2, bw, bh / 2)
            } else {
                tmpRect.set(-bw / 2, -bh, bw / 2, 0f)
            }
            canvas.drawBitmap(bmp, null, tmpRect, bmpPaint)
            canvas.restore()
        }
        val held = f.throwable
        if (held != null) {
            canvas.save()
            canvas.translate(handX, handY)
            drawSpriteFit(canvas, held.sprite, H * 0.06f)
            canvas.restore()
        }
    }

    private fun drawHud(canvas: Canvas) {
        val barW = W * 0.28f
        val barH = H * 0.03f
        val y = H * 0.06f
        val pad = W * 0.03f
        text.textSize = H * 0.035f
        text.color = Color.WHITE

        text.textAlign = Paint.Align.LEFT
        canvas.drawText(player.name + (player.weapon?.let { " · ${it.label}" } ?: ""), pad, y - H * 0.012f, text)
        drawBar(canvas, pad, y, barW, barH, player.hp, player.color, false)

        text.textAlign = Paint.Align.RIGHT
        canvas.drawText((enemy.weapon?.let { "${it.label} · " } ?: "") + enemy.name, W - pad, y - H * 0.012f, text)
        drawBar(canvas, W - pad - barW, y, barW, barH, enemy.hp, enemy.color, true)
    }

    private fun drawBar(canvas: Canvas, x: Float, y: Float, w: Float, h: Float, hp: Int, color: Int, fromRight: Boolean) {
        fill.color = Color.parseColor("#1E242D")
        canvas.drawRoundRect(x, y, x + w, y + h, h / 2, h / 2, fill)
        val fw = w * hp / 100f
        fill.color = color
        if (fw > 0f) {
            if (fromRight) canvas.drawRoundRect(x + w - fw, y, x + w, y + h, h / 2, h / 2, fill)
            else canvas.drawRoundRect(x, y, x + fw, y + h, h / 2, h / 2, fill)
        }
    }

    private fun drawControls(canvas: Canvas) {
        drawButton(canvas, btnLeft, holdLeft, Color.parseColor("#1B2129"))
        drawArrow(canvas, btnLeft, -1)
        drawButton(canvas, btnRight, holdRight, Color.parseColor("#1B2129"))
        drawArrow(canvas, btnRight, 1)
        drawButton(canvas, btnJump, false, Color.parseColor("#1B2129"))
        drawLabel(canvas, btnJump, "Jump", Color.WHITE)
        drawButton(canvas, btnAttack, false, Color.parseColor("#FF9F4A"))
        drawLabel(canvas, btnAttack, if (player.throwable != null) "Throw" else "Hit", Color.parseColor("#0E1116"))
    }

    private fun drawButton(canvas: Canvas, c: PointF, pressed: Boolean, color: Int) {
        fill.color = color
        fill.alpha = if (pressed) 255 else 215
        canvas.drawCircle(c.x, c.y, btnR, fill)
        fill.alpha = 255
        stroke.color = Color.parseColor("#3A424E")
        stroke.strokeWidth = H * 0.004f
        canvas.drawCircle(c.x, c.y, btnR, stroke)
    }

    private fun drawArrow(canvas: Canvas, c: PointF, dir: Int) {
        val s = btnR * 0.4f
        arrow.reset()
        arrow.moveTo(c.x + dir * s, c.y)
        arrow.lineTo(c.x - dir * s * 0.6f, c.y - s)
        arrow.lineTo(c.x - dir * s * 0.6f, c.y + s)
        arrow.close()
        fill.color = Color.WHITE
        canvas.drawPath(arrow, fill)
    }

    private fun drawLabel(canvas: Canvas, c: PointF, label: String, color: Int) {
        text.textAlign = Paint.Align.CENTER
        text.textSize = btnR * 0.42f
        text.color = color
        canvas.drawText(label, c.x, c.y + text.textSize * 0.35f, text)
    }

    // ---------- touch (multi-touch: move and jump/hit at the same time) ----------

    private fun inButton(c: PointF, x: Float, y: Float) = hypot(x - c.x, y - c.y) < btnR * 1.3f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val action = e.actionMasked
        if (gameOver) {
            if (action == MotionEvent.ACTION_DOWN && overTime > 0.8f) buildWorld()
            return true
        }
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex
            if (inButton(btnJump, e.getX(i), e.getY(i))) jumpQueued = true
            if (inButton(btnAttack, e.getX(i), e.getY(i))) attackQueued = true
        }
        holdLeft = false
        holdRight = false
        if (action != MotionEvent.ACTION_UP && action != MotionEvent.ACTION_CANCEL) {
            for (i in 0 until e.pointerCount) {
                if (action == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                if (inButton(btnLeft, e.getX(i), e.getY(i))) holdLeft = true
                if (inButton(btnRight, e.getX(i), e.getY(i))) holdRight = true
            }
        }
        return true
    }
}
