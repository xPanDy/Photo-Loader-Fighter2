package com.photoarena.game

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import java.io.Closeable
import kotlin.math.ceil
import kotlin.math.floor

/**
 * Finds everyday objects in a photo, fully on the phone (no internet needed).
 * Uses MediaPipe with EfficientDet-Lite0, trained on the COCO dataset
 * (80 objects, including toothbrush, sink, chair, bottle, cup...).
 */
class Detector(context: Context) : Closeable {

    private val detector: ObjectDetector

    init {
        val base = BaseOptions.builder()
            .setModelAssetPath("efficientdet_lite0.tflite")
            .build()
        val options = ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.IMAGE)
            .setMaxResults(12)
            .setScoreThreshold(0.30f)
            .build()
        detector = ObjectDetector.createFromOptions(context, options)
    }

    fun detect(photo: Bitmap): List<DetectedItem> {
        val result = detector.detect(BitmapImageBuilder(photo).build())
        val items = mutableListOf<DetectedItem>()

        for (d in result.detections()) {
            val cat = d.categories().firstOrNull() ?: continue
            val label = cat.categoryName() ?: continue
            val role = Roles.roleFor(label) ?: continue

            val b = d.boundingBox()
            val l = floor(b.left).toInt().coerceIn(0, photo.width - 1)
            val t = floor(b.top).toInt().coerceIn(0, photo.height - 1)
            val r = ceil(b.right).toInt().coerceIn(l + 1, photo.width)
            val btm = ceil(b.bottom).toInt().coerceIn(t + 1, photo.height)
            if (r - l < 8 || btm - t < 8) continue

            val sprite = Bitmap.createBitmap(photo, l, t, r - l, btm - t)
            items += DetectedItem(
                label = label,
                role = role,
                score = cat.score(),
                box = RectF(l.toFloat(), t.toFloat(), r.toFloat(), btm.toFloat()),
                sprite = sprite
            )
        }
        return items
    }

    override fun close() = detector.close()
}
