plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.photoarena.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.photoarena.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    // The detection model must stay uncompressed inside the APK.
    androidResources {
        noCompress += "tflite"
    }
}

// Downloads the object detection model (COCO, 80 everyday objects) on the first build.
val modelFile = file("src/main/assets/efficientdet_lite0.tflite")
val downloadModel by tasks.registering {
    outputs.file(modelFile)
    onlyIf { !modelFile.exists() }
    doLast {
        modelFile.parentFile.mkdirs()
        val url = java.net.URL(
            "https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/1/efficientdet_lite0.tflite"
        )
        url.openStream().use { input -> modelFile.outputStream().use { input.copyTo(it) } }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadModel) }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}
